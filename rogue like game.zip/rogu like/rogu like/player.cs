﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rogu_like
{
    internal class player
    {
        public string nameC = string.Empty;
        public int Hp = 50;

    }
}
